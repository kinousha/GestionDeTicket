class Ticket < ApplicationRecord
    belongs_to :personne
end