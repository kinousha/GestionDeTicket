class Personne < ApplicationRecord
    has_many :tickets 
end